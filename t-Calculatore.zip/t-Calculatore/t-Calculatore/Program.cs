﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t_Calculatore
{
    internal class Program
    {


        class Calculatore
        {
            private int num1;
            private int num2;
            private string Char;


            public Calculatore(int num1, int num2)
            {
                this.num1 = num1;
                this.num2 = num2;
                this.Char = Char;
            }
            public int Plus()
            {
                return (this.num1 + this.num2);
            }
            public int Zarb()
            {
                return (this.num1 * this.num2);
            }
            public Double Taghsim()
            {
                return (this.num1 / this.num2);
            }
            public int Tafrigh()
            {
                return (this.num1 - this.num2);
            }
            static void Main(string[] args)
            {
                // creating an object
                while (true)
                {
                    try
                    {
                        Console.WriteLine("enter 2 numbers");
                        int num1 = Convert.ToInt32(Console.ReadLine());
                        int num2 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter your char");
                        string Char = Console.ReadLine();
                        Calculatore Equls = new Calculatore(num1, num2);
                        if (Char == "+")
                        {
                            Console.WriteLine("result");
                            Console.WriteLine(Equls.Plus());
                        }
                        else if (Char == "/")
                        {
                            Console.WriteLine("result");
                            Console.WriteLine(Equls.Taghsim());
                        }
                        else if (Char == "-")
                        {
                            Console.WriteLine("result");
                            Console.WriteLine(Equls.Tafrigh());
                        }
                        else
                        {
                            Console.WriteLine("result");
                            Console.WriteLine(Equls.Zarb());
                        }
                        Console.ReadLine();

                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }

                }





            }
        }
    }
}
