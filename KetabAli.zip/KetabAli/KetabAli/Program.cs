﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KetabAli
{
    internal class Program
    {
        // Static list to hold the book objects
        static List<Book> books = new List<Book>();
        static List<order> orders = new List<order>();

        // Book class to represent each book
        public class Book
        {
            public string Name { get; set; }
            public string Writer { get; set; }
            public int Price { get; set; }

            public Book(string name, string writer, int price)
            {
                Name = name;
                Writer = writer;
                Price = price;
            }
        }
        public class order
        {
            public string Name { get; set; }
            public order(string name)
            {
                this.Name = name;

            }

        }

        // Method to add a book
        public static void AddBook(string name, string writer, int price)
        {
            books.Add(new Book(name, writer, price));
        }

        // Method to add a book to the orders
        public static void AddOrder(string name)
        {
            orders.Add(new order(name));
        }

        // Method to remove a book 
        public static void DeleteBook(string name)
        {
            Book removebook = books.Find(b => b.Name == name);
            if (removebook != null)
            {
                books.Remove(removebook);
                Console.WriteLine("Book removed successfully!");

            }
            else
            {
                Console.WriteLine("book not found");

            }

        }
        // Method to display all books
        public static void DisplayBooks()
        {
            bool availablebooks = false;
            foreach (var book in books)
            {
                Console.WriteLine($"Name: {book.Name}, Writer: {book.Writer}, Price: {book.Price}");
                availablebooks = true;
            }

            if (!availablebooks)
            {
                Console.WriteLine("No books available.");
            }
        }

        // Method to display all orders
        public static void DisplayOrders()
        {
            bool availableorder = false;
            foreach (var order in orders)
            {
                Console.WriteLine($"Name: {order.Name},");
                availableorder = true;
            }

            if (!availableorder)
            {
                Console.WriteLine("No orders available.");
            }
        }

        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("Choose who you are:");
                    Console.WriteLine("1. Librarian");
                    Console.WriteLine("2. Reader");
                    string IAM = Console.ReadLine();

                    if (IAM == "1")
                    {
                        Console.Clear();
                        Console.WriteLine("What do you want to do?");
                        Console.WriteLine("1. Add a book");
                        Console.WriteLine("2. Delete a book");
                        string TODO = Console.ReadLine();

                        if (TODO == "1")
                        {
                            Console.Clear();
                            Console.WriteLine("Enter name of the book:");
                            string name = Console.ReadLine();
                            Console.WriteLine("Enter name of the writer:");
                            string writer = Console.ReadLine();
                            Console.WriteLine("Enter price:");
                            int price = Convert.ToInt32(Console.ReadLine());

                            AddBook(name, writer, price);
                            Console.WriteLine("Book added successfully!");

                        }
                        else if (TODO == "2")
                        {
                            Console.Clear();
                            Console.WriteLine("Enter name of the book to remove:");
                            string name = Console.ReadLine();
                            DeleteBook(name);
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Error: Invalid selection!");
                        }
                    }
                    else if (IAM == "2")
                    {
                        Console.Clear();
                        Console.WriteLine("What do you want to do?");
                        Console.WriteLine("1. Show me the list of books");
                        Console.WriteLine("2. Order books");
                        Console.WriteLine("3. Cart");
                        string TODO2 = Console.ReadLine();

                        if (TODO2 == "1")
                        {
                            Console.Clear();
                            DisplayBooks();
                            Console.Write("Press Enter to go back to the menu");
                            Console.ReadLine();
                        }
                        else if (TODO2 == "2")
                        {
                            Console.Clear();
                            DisplayBooks();
                            Console.Write("Enter the name of the book that you want: ");
                            string ordername = Console.ReadLine();
                            AddOrder(ordername);
                            Console.WriteLine("Book ordered successfully!");
                            Console.ReadLine();
                        }
                        else if (TODO2 == "3")
                        {
                            Console.Clear();
                            Console.WriteLine("Your orders:");
                            DisplayOrders();
                            Console.Write("Press Enter to go back to the menu");
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Error: Invalid selection!");
                        }
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Error: Invalid role selection!");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine($"{e.Message} Press Enter to start over.");
                    Console.ReadLine();
                    Console.Clear();
                }
            }
        }
    }
}
